<?php
//$flag = $_GET["flag"];
//if($flag ==1){
//$list=array("name"=>"wang","sex"=>"man","tel"=>"123","email"=>"xxx@126.com"); 
//$list1=array("name"=>"sdfa","sex"=>"g","tel"=>"ddd","email"=>"ccc126.com"); 
//$re = array($list,$list1);
    echo '{"records":[{"name":3,"city":"wash"},{"name":5,"city":"22222222"},{"name":6,"city":"a1111111"}]}';
?>
